# 门店开货单系统

这是一个可以部署到公网的门店报货系统。

员工用手机打开公网链接，选择门店和日期，填写固定品类数量后提交。后台会自动保存数据、生成采购明细长表、按品类汇总，并支持导出 CSV。

## 一、系统地址

本地运行时：

- 员工填写页：http://localhost:3000/
- 后台管理页：http://localhost:3000/admin

部署到公网后：

- 员工填写页：`https://你的域名/`
- 后台管理页：`https://你的域名/admin`

员工填写页不需要登录。后台管理页需要密码登录。

## 二、为什么不能直接发 localhost:3000

`localhost:3000` 只代表“当前这台电脑自己”。

如果你把 `http://localhost:3000/` 发到微信群，员工手机打开时，手机会去找“手机自己”的 3000 端口，不会访问你的电脑，所以打不开。

正式使用必须部署到 Render、Railway、云服务器等公网环境，然后把公网地址发给员工。

## 三、技术方案

- 后端：Node.js + Express
- 页面：EJS + HTML + CSS + JavaScript
- 数据库：PostgreSQL
- session：PostgreSQL 保存后台登录状态
- 导出：CSV

数据保存在 PostgreSQL 里，服务器重启或重新部署后不会丢失。

## 四、本地运行方法

### 1. 安装 Node.js

安装 Node.js 18 或更高版本，建议安装 LTS 版本：

```text
https://nodejs.org/
```

安装后打开 PowerShell，检查：

```powershell
node -v
npm -v
```

### 2. 准备 PostgreSQL

你需要一个 PostgreSQL 数据库。本地测试可以用本机 PostgreSQL，也可以直接使用 Supabase、Neon、Railway、Render 提供的 PostgreSQL。

你需要拿到数据库连接字符串，格式类似：

```text
postgresql://用户名:密码@主机:端口/数据库名
```

这就是 `DATABASE_URL`。

### 3. 创建 .env 文件

在项目目录里复制示例文件：

```powershell
Copy-Item .env.example .env
```

然后打开 `.env`，填写：

```env
PORT=3000
DATABASE_URL=postgresql://postgres:password@localhost:5432/store_orders
DATABASE_SSL=false
ADMIN_PASSWORD=123456
SESSION_SECRET=请换成一串很长的随机字符
```

说明：

- `DATABASE_URL`：PostgreSQL 连接字符串。
- `DATABASE_SSL=false`：本地数据库通常填 `false`。
- `ADMIN_PASSWORD`：后台登录密码。
- `SESSION_SECRET`：后台登录 session 密钥，正式使用一定要改成长一点的随机字符串。

### 4. 安装依赖

```powershell
npm install
```

### 5. 初始化数据库

```powershell
npm run init-db
```

项目启动时也会自动检查并创建表，但第一次部署前手动运行一次更直观。

### 6. 启动项目

```powershell
npm start
```

看到类似下面的输出就表示启动成功：

```text
门店开货单系统已启动：http://localhost:3000
```

然后打开：

- 员工填写页：http://localhost:3000/
- 后台管理页：http://localhost:3000/admin

## 五、如何导出 CSV

登录后台后：

1. 打开 `/admin`。
2. 可以选择日期。
3. 可以选择门店。
4. 点击“导出 CSV”。

导出的 CSV 字段：

- 日期
- 门店
- 品类
- 数量
- 提交时间

如果选择了某个日期，只导出该日期数据。如果没有选择日期，导出全部数据。

CSV 文件名格式：

```text
purchase_orders_YYYY-MM-DD.csv
```

没有选择日期时，文件名为：

```text
purchase_orders_all.csv
```

CSV 带有 UTF-8 BOM，可以用 Excel 或 WPS 打开。

## 六、部署到 Render

### 最简单方式：Render Blueprint

本项目已经包含 `render.yaml`。上传到 GitHub 后，可以在 Render 里选择 Blueprint 部署。

Render 会自动创建：

- Web Service
- PostgreSQL 数据库
- `DATABASE_URL`
- `SESSION_SECRET`

你只需要填写 `ADMIN_PASSWORD`。

详细步骤可以看 `DEPLOY_NOW.md`。

### 1. 上传到 GitHub

先把这个项目上传到一个 GitHub 仓库。

### 2. 创建 PostgreSQL

在 Render 里创建 PostgreSQL 数据库。

创建后，在数据库页面找到连接字符串。通常可以复制 External Database URL 或 Internal Database URL。

把这个连接字符串作为 `DATABASE_URL`。

如果 Render 的连接要求 SSL，请设置：

```env
DATABASE_SSL=true
```

### 3. 创建 Web Service

在 Render 新建 Web Service：

1. 选择你的 GitHub 仓库。
2. Build Command 填：

```bash
npm install
```

3. Start Command 填：

```bash
npm start
```

### 4. 设置环境变量

在 Render 的 Environment 里添加：

```env
DATABASE_URL=你的 PostgreSQL 连接字符串
DATABASE_SSL=true
ADMIN_PASSWORD=你的后台密码
SESSION_SECRET=一串很长的随机字符
NODE_ENV=production
```

`PORT` 不需要自己设置，Render 会自动提供。

### 5. 部署完成后访问

Render 部署完成后会给你一个公网 URL，例如：

```text
https://store-orders.onrender.com
```

员工填写页：

```text
https://store-orders.onrender.com/
```

后台管理页：

```text
https://store-orders.onrender.com/admin
```

## 七、部署到 Railway

### 1. 上传到 GitHub

先把项目上传到 GitHub。

### 2. Railway 新建项目

在 Railway 新建项目，选择从 GitHub 仓库部署。

### 3. 添加 PostgreSQL 数据库

在 Railway 项目里添加 PostgreSQL。

Railway 通常会自动生成 `DATABASE_URL`。如果没有自动注入，就手动复制 PostgreSQL 的连接字符串并添加到 Web 服务变量里。

### 4. 设置环境变量

在 Railway 的 Variables 里添加：

```env
DATABASE_URL=你的 PostgreSQL 连接字符串
DATABASE_SSL=false
ADMIN_PASSWORD=你的后台密码
SESSION_SECRET=一串很长的随机字符
NODE_ENV=production
```

如果你的 Railway PostgreSQL 明确要求 SSL，再把 `DATABASE_SSL` 改成 `true`。

### 5. 设置启动命令

启动命令使用：

```bash
npm start
```

### 6. 生成公网域名

在 Railway 服务设置里生成公网域名。

员工填写页：

```text
https://你的域名/
```

后台管理页：

```text
https://你的域名/admin
```

## 八、部署成功后怎么发给员工

部署成功后，把员工填写页链接发到微信群即可。

例如：

```text
各门店每天报货请打开：
https://你的域名/
```

员工不需要登录，打开后选择门店和日期，填写数量并提交。

后台地址不要发到员工群，只给管理员使用：

```text
https://你的域名/admin
```

## 九、如何修改后台密码

修改环境变量：

```env
ADMIN_PASSWORD=新的后台密码
```

修改后重新部署或重启服务。

## 十、如何设置 SESSION_SECRET

`SESSION_SECRET` 用于保护后台登录状态。

可以随便生成一串长字符，例如：

```env
SESSION_SECRET=store-order-2026-random-long-secret-change-me
```

正式使用不要用示例值。

## 十一、如何修改门店列表

打开 `config.js`，修改 `stores` 数组：

```js
const stores = [
  '乐创店',
  '文耀店'
];
```

保存后重新部署或重启服务。

## 十二、如何修改品类列表

打开 `config.js`，修改 `items` 数组：

```js
const items = [
  '洋葱',
  '鸡蛋',
  '土豆'
];
```

保存后重新部署或重启服务。

员工填写页会固定展示这里配置的品类。提交时仍然只保存数量大于 0 的品类。

## 十三、如何备份数据

数据在 PostgreSQL 里，不在项目代码里。

备份方式取决于你使用的平台：

- Render PostgreSQL：在 Render 数据库页面查看备份或导出功能。
- Railway PostgreSQL：在 Railway 数据库页面查看备份、导出或连接信息。
- Supabase/Neon：在对应平台后台查看备份功能。
- 自己的云服务器：使用 `pg_dump` 备份数据库。

通用备份命令示例：

```bash
pg_dump "你的 DATABASE_URL" > backup.sql
```

恢复时可以使用：

```bash
psql "你的 DATABASE_URL" < backup.sql
```

## 十四、数据库表

系统会自动创建两张业务表：

### orders

保存每次提交的主记录：

- id
- store_name
- order_date
- other_items_note
- remark
- created_at
- updated_at

### order_items

保存每次提交里数量大于 0 的品类明细：

- id
- order_id
- item_name
- quantity
- created_at

同一个门店同一天允许多次提交，每次提交都是独立记录。以后如果要改成“同门店同日期只能提交一次”，可以在 `orders` 表增加唯一约束，并在 `/api/orders` 提交逻辑里改成更新或拒绝重复提交。

## 十五、常见问题

### 1. npm start 后提示缺少 DATABASE_URL

说明没有创建 `.env`，或者 `.env` 里没有写 `DATABASE_URL`。

### 2. 后台打不开或登录后又跳回登录页

检查 `SESSION_SECRET` 是否设置。正式部署时也要确认 PostgreSQL 可以连接，因为后台登录状态存在 PostgreSQL session 表里。

### 3. 数据库连接失败

检查：

- `DATABASE_URL` 是否复制完整。
- 数据库是否还在运行。
- Render 是否需要 `DATABASE_SSL=true`。
- Railway 如果 SSL 报错，可以尝试 `DATABASE_SSL=false`。

### 4. 员工手机打不开

不要发 `localhost:3000`。

请发部署后的公网链接，例如：

```text
https://你的域名/
```

### 5. 重新部署后数据会不会丢

不会。数据保存在 PostgreSQL 数据库里，不保存在项目临时目录里。
