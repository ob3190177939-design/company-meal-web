require('dotenv').config();

const { pool } = require('./db');
const { initializeDatabase } = require('./schema');

async function initDb() {
  await initializeDatabase(pool);
  console.log('PostgreSQL database initialized.');
}

initDb()
  .catch((error) => {
    console.error('Failed to initialize PostgreSQL database:', error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
