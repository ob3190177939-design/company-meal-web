(function () {
  const form = document.getElementById('orderForm');
  const message = document.getElementById('formMessage');
  const successPanel = document.getElementById('successPanel');
  const submittedMeta = document.getElementById('submittedMeta');
  const submittedItems = document.getElementById('submittedItems');
  const nextOrderButton = document.getElementById('nextOrderButton');

  function showMessage(text, type) {
    message.textContent = text || '';
    message.className = `form-message ${type || ''}`.trim();
  }

  function validateForm(formData) {
    if (!formData.get('storeName')) return '请选择门店';
    if (!formData.get('orderDate')) return '请选择日期';

    const quantityInputs = form.querySelectorAll('input[type="number"][data-item-name]');
    for (const input of quantityInputs) {
      const value = input.value.trim();
      if (!value) continue;
      const numberValue = Number(value);
      if (!Number.isFinite(numberValue)) return `${input.dataset.itemName} 的数量必须是数字`;
      if (numberValue < 0) return `${input.dataset.itemName} 的数量不能为负数`;
    }

    return '';
  }

  function buildPayload() {
    const formData = new FormData(form);
    const quantities = {};
    form.querySelectorAll('input[type="number"][data-item-name]').forEach((input) => {
      quantities[input.dataset.itemName] = input.value.trim();
    });

    return {
      storeName: formData.get('storeName'),
      orderDate: formData.get('orderDate'),
      quantities,
      otherItemsNote: formData.get('otherItemsNote'),
      remark: formData.get('remark')
    };
  }

  function renderSuccess(order) {
    submittedMeta.innerHTML = `
      <p><strong>门店：</strong>${escapeHtml(order.storeName)}</p>
      <p><strong>日期：</strong>${escapeHtml(order.orderDate)}</p>
    `;

    if (!order.items.length) {
      submittedItems.innerHTML = '<p class="muted">本次没有填写数量大于 0 的固定品类。</p>';
    } else {
      const rows = order.items
        .map((item) => `<li><span>${escapeHtml(item.itemName)}</span><strong>${escapeHtml(item.displayQuantity)}</strong></li>`)
        .join('');
      submittedItems.innerHTML = `<ul class="submitted-list">${rows}</ul>`;
    }

    if (order.otherItemsNote) {
      submittedItems.insertAdjacentHTML(
        'beforeend',
        `<p class="note-line"><strong>其他品类备注：</strong>${escapeHtml(order.otherItemsNote)}</p>`
      );
    }
    if (order.remark) {
      submittedItems.insertAdjacentHTML(
        'beforeend',
        `<p class="note-line"><strong>备注：</strong>${escapeHtml(order.remark)}</p>`
      );
    }

    form.classList.add('hidden');
    successPanel.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    showMessage('');

    const formData = new FormData(form);
    const validationError = validateForm(formData);
    if (validationError) {
      showMessage(validationError, 'error');
      return;
    }

    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = '提交中...';

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildPayload())
      });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || '提交失败，请稍后重试');
      renderSuccess(result.order);
    } catch (error) {
      showMessage(error.message || '服务器错误，请稍后重试', 'error');
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = '提交开货单';
    }
  });

  nextOrderButton.addEventListener('click', () => {
    const currentDate = form.querySelector('input[name="orderDate"]').value;
    form.reset();
    form.querySelector('input[name="orderDate"]').value = currentDate;
    successPanel.classList.add('hidden');
    form.classList.remove('hidden');
    showMessage('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();
