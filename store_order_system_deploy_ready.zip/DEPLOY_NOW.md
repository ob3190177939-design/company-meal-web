# 立刻部署成手机可打开的公网版本

项目已经准备好部署到 Render。部署成功后，员工手机打开公网链接即可报货。

## 你需要做的事

### 1. 确认这几个文件已经上传到 GitHub

仓库根目录必须有：

```text
package.json
server.js
db.js
schema.js
init-db.js
config.js
render.yaml
.env.example
.gitignore
views/
public/
```

### 2. 打开 Render

访问：

```text
https://render.com/
```

登录后点击：

```text
New + -> Blueprint
```

### 3. 选择你的 GitHub 仓库

选择：

```text
store_order_system
```

Render 会读取项目里的 `render.yaml`，自动创建：

- 一个 Web Service
- 一个 PostgreSQL 数据库
- `DATABASE_URL`
- `SESSION_SECRET`

### 4. 设置后台密码

Render 会要求你填写 `ADMIN_PASSWORD`。

例如：

```text
123456
```

正式使用请换成更强的密码。

### 5. 点击部署

等待部署完成。

部署成功后，Render 会给你一个公网地址，例如：

```text
https://store-order-system.onrender.com
```

员工填写页：

```text
https://store-order-system.onrender.com/
```

后台管理页：

```text
https://store-order-system.onrender.com/admin
```

## 发给员工的链接

把员工填写页发到微信群：

```text
各门店每天报货请打开：
https://你的Render域名/
```

不要发：

```text
http://localhost:3000/
```

`localhost` 只能在你自己的电脑上访问，员工手机打不开。

## 后台登录

管理员打开：

```text
https://你的Render域名/admin
```

输入你在 Render 里设置的 `ADMIN_PASSWORD`。

## 数据会不会丢

不会。数据保存在 Render PostgreSQL 里，不保存在临时文件夹里。
