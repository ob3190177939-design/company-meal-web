require('dotenv').config();

const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const path = require('path');
const db = require('./db');
const { initializeDatabase } = require('./schema');
const { stores, items } = require('./config');

const app = express();
const port = Number(process.env.PORT || 3000);
const adminPassword = process.env.ADMIN_PASSWORD;
const sessionSecret = process.env.SESSION_SECRET;

if (!adminPassword) {
  throw new Error('缺少 ADMIN_PASSWORD 环境变量。');
}

if (!sessionSecret) {
  throw new Error('缺少 SESSION_SECRET 环境变量。');
}

app.set('trust proxy', 1);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(
  session({
    store: new PgSession({
      pool: db.pool,
      tableName: 'session',
      createTableIfMissing: true
    }),
    name: 'store_order_sid',
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 8
    }
  })
);

function todayISO() {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  const local = new Date(now.getTime() - offset * 60 * 1000);
  return local.toISOString().slice(0, 10);
}

function isValidDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.redirect('/admin/login');
}

function asyncHandler(handler) {
  return (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}

function normalizeOrderPayload(body) {
  const storeName = String(body.storeName || '').trim();
  const orderDate = String(body.orderDate || '').trim();
  const quantities = body.quantities || {};
  const otherItemsNote = String(body.otherItemsNote || '').trim();
  const remark = String(body.remark || '').trim();

  if (!storeName) throw new Error('请选择门店');
  if (!stores.includes(storeName)) throw new Error('门店名称无效');
  if (!orderDate) throw new Error('请选择日期');
  if (!isValidDate(orderDate)) throw new Error('日期格式无效');

  const orderItems = [];
  for (const itemName of items) {
    const rawValue = quantities[itemName];
    if (rawValue === undefined || rawValue === null || String(rawValue).trim() === '') continue;

    const normalized = String(rawValue).trim();
    const quantity = Number(normalized);
    if (!Number.isFinite(quantity)) throw new Error(`${itemName} 的数量必须是数字`);
    if (quantity < 0) throw new Error(`${itemName} 的数量不能为负数`);
    if (quantity > 0) orderItems.push({ itemName, quantity, displayQuantity: normalized });
  }

  return { storeName, orderDate, orderItems, otherItemsNote, remark };
}

function buildFilterWhere(filters, startIndex = 1) {
  const conditions = [];
  const params = [];
  let index = startIndex;

  if (filters.date) {
    conditions.push(`o.order_date = $${index}`);
    params.push(filters.date);
    index += 1;
  }
  if (filters.store) {
    conditions.push(`o.store_name = $${index}`);
    params.push(filters.store);
    index += 1;
  }

  return {
    where: conditions.length ? `WHERE ${conditions.join(' AND ')}` : '',
    params
  };
}

function normalizeFilters(query) {
  return {
    date: isValidDate(query.date) ? query.date : '',
    store: stores.includes(query.store) ? query.store : ''
  };
}

async function getAdminData(filters) {
  const { where, params } = buildFilterWhere(filters);

  const recordsResult = await db.query(
    `
      SELECT
        o.id,
        o.store_name,
        to_char(o.order_date, 'YYYY-MM-DD') AS order_date,
        o.other_items_note,
        o.remark,
        to_char(o.created_at AT TIME ZONE 'Asia/Shanghai', 'YYYY-MM-DD HH24:MI:SS') AS created_at,
        COUNT(oi.id)::int AS item_count,
        COALESCE(SUM(oi.quantity), 0)::float AS quantity_total
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      ${where}
      GROUP BY o.id
      ORDER BY o.created_at DESC, o.id DESC
    `,
    params
  );

  const detailsResult = await db.query(
    `
      SELECT
        o.id AS order_id,
        to_char(o.order_date, 'YYYY-MM-DD') AS order_date,
        o.store_name,
        oi.item_name,
        oi.quantity::float AS quantity,
        to_char(o.created_at AT TIME ZONE 'Asia/Shanghai', 'YYYY-MM-DD HH24:MI:SS') AS created_at
      FROM order_items oi
      JOIN orders o ON o.id = oi.order_id
      ${where}
      ORDER BY o.order_date DESC, o.store_name ASC, oi.item_name ASC, oi.id ASC
    `,
    params
  );

  const summaryResult = await db.query(
    `
      SELECT oi.item_name, SUM(oi.quantity)::float AS total_quantity
      FROM order_items oi
      JOIN orders o ON o.id = oi.order_id
      ${where}
      GROUP BY oi.item_name
      ORDER BY total_quantity DESC, oi.item_name ASC
    `,
    params
  );

  const itemsByOrder = {};
  for (const row of detailsResult.rows) {
    if (!itemsByOrder[row.order_id]) itemsByOrder[row.order_id] = [];
    itemsByOrder[row.order_id].push(row);
  }

  return {
    records: recordsResult.rows,
    details: detailsResult.rows,
    summary: summaryResult.rows,
    itemsByOrder
  };
}

function csvEscape(value) {
  const text = value === null || value === undefined ? '' : String(value);
  if (/[",\r\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

function makeCsv(rows) {
  const header = ['日期', '门店', '品类', '数量', '提交时间'];
  const lines = [header.map(csvEscape).join(',')];
  for (const row of rows) {
    lines.push(
      [row.order_date, row.store_name, row.item_name, row.quantity, row.created_at]
        .map(csvEscape)
        .join(',')
    );
  }
  return `\uFEFF${lines.join('\r\n')}`;
}

app.get('/', (req, res) => {
  res.render('index', {
    stores,
    items,
    today: todayISO()
  });
});

app.post(
  '/api/orders',
  asyncHandler(async (req, res) => {
    let payload;
    try {
      payload = normalizeOrderPayload(req.body);
    } catch (error) {
      return res.status(400).json({ ok: false, message: error.message });
    }

    const orderId = await db.transaction(async (client) => {
      const orderResult = await client.query(
        `
          INSERT INTO orders (store_name, order_date, other_items_note, remark)
          VALUES ($1, $2, $3, $4)
          RETURNING id
        `,
        [payload.storeName, payload.orderDate, payload.otherItemsNote, payload.remark]
      );
      const id = orderResult.rows[0].id;

      for (const item of payload.orderItems) {
        await client.query(
          `
            INSERT INTO order_items (order_id, item_name, quantity)
            VALUES ($1, $2, $3)
          `,
          [id, item.itemName, item.quantity]
        );
      }

      return id;
    });

    return res.json({
      ok: true,
      message: '提交成功',
      order: {
        id: orderId,
        storeName: payload.storeName,
        orderDate: payload.orderDate,
        items: payload.orderItems,
        otherItemsNote: payload.otherItemsNote,
        remark: payload.remark
      }
    });
  })
);

app.get('/admin/login', (req, res) => {
  res.render('login', { error: '' });
});

app.post('/admin/login', (req, res) => {
  if (String(req.body.password || '') === adminPassword) {
    req.session.isAdmin = true;
    return res.redirect('/admin');
  }
  return res.status(401).render('login', { error: '密码错误' });
});

app.post('/admin/logout', requireAdmin, (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

app.get(
  '/admin',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const filters = normalizeFilters(req.query);
    const data = await getAdminData(filters);
    res.render('admin', {
      stores,
      filters,
      ...data
    });
  })
);

app.get(
  '/admin/export.csv',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const filters = normalizeFilters(req.query);
    const { details } = await getAdminData(filters);
    const filenameDate = filters.date || 'all';
    const filename = `purchase_orders_${filenameDate}.csv`;

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(makeCsv(details));
  })
);

app.post(
  '/admin/orders/:id/delete',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    if (Number.isInteger(id) && id > 0) {
      await db.query('DELETE FROM orders WHERE id = $1', [id]);
    }

    const query = new URLSearchParams();
    if (req.body.date) query.set('date', req.body.date);
    if (req.body.store) query.set('store', req.body.store);
    res.redirect(`/admin${query.toString() ? `?${query.toString()}` : ''}`);
  })
);

app.use((req, res) => {
  res.status(404).send('页面不存在');
});

app.use((error, req, res, next) => {
  console.error(error);
  if (req.path.startsWith('/api/')) {
    return res.status(500).json({ ok: false, message: '服务器错误，请稍后重试' });
  }
  return res.status(500).send('服务器错误，请稍后重试');
});

async function start() {
  await initializeDatabase(db.pool);
  app.listen(port, '0.0.0.0', () => {
    console.log(`门店开货单系统已启动：http://localhost:${port}`);
  });
}

start().catch((error) => {
  console.error('启动失败：', error.message);
  process.exit(1);
});
